//
//  CaddyTrackCoachSDK.h
//  CaddyTrackCoachSDK
//
//  Created by Abcom on 31/03/25.
//

#import <Foundation/Foundation.h>

//! Project version number for CaddyTrackCoachSDK.
FOUNDATION_EXPORT double CaddyTrackCoachSDKVersionNumber;

//! Project version string for CaddyTrackCoachSDK.
FOUNDATION_EXPORT const unsigned char CaddyTrackCoachSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CaddyTrackCoachSDK/PublicHeader.h>
